#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QGraphicsScene>

//#include <../../QtSerialPort/qtserialport-build/include/QtSerialPort/QSerialPort>
//#include <../../QtSerialPort/qtserialport-build/include/QtSerialPort/QSerialPortInfo>

#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>

//#include "qextserialport.h"
//#include "qextserialenumerator.h"

#include "cmath"
#include <stdint.h>

// #include "adcflt.h"


#define KEY_ZERO       60
#define KEY_TARE       61
#define LONG_PRESS     0x80
#define FAKEGRD_CNT    10
const uint8_t fakegrd_sequence[FAKEGRD_CNT] =
     {
       KEY_ZERO,
       KEY_ZERO, KEY_ZERO + LONG_PRESS,
       KEY_TARE, KEY_TARE + LONG_PRESS,
       KEY_TARE,
       KEY_TARE, KEY_TARE + LONG_PRESS,
       KEY_ZERO, KEY_ZERO + LONG_PRESS
     };


#define  SM_DEFAULT                  SM_TRY_OPEN_CURRENT_PORT
#define  SM_TRY_OPEN_CURRENT_PORT    10
#define  SM_TRY_SET_BAUD_RATE        20
#define  SM_TRY_CONNECT              30
#define  SM_CONNECTED                40
#define  SM_NO_DEVICE_CONNECTED      50

// ��������� �������� ������� �������
#define  SCS_SEND_ENQ            0
#define  SCS_WAITING_FOR_NAK    10
#define  SCS_WAITING_FOR_ACK    20
#define  SCS_WAITING_FOR_REPLY  30
#define  SCS_SUCCESS            40
#define  SCS_FAILED             50

// ��������� �������� ������� �������. ����. ������
#define  SFG_PREPARE_SEND_KEY    0
#define  SFG_ROUTINE_SEND_KEY   10
#define  SFG_DELAY              20
#define  SFG_SUCCESS            80
#define  SFG_FAILED             90

// ��������� �������� ��������� ���������� � ����� � ����� �����������
#define  SCN_PREPARE_GET_DEV_TYPE    0
#define  SCN_ROUTINE_GET_DEV_TYPE   10
#define  SCN_ROUTINE_GET_CHN_INFO   20
#define  SCN_ROUTINE_CHECK_MODE_1   30
#define  SCN_ROUTINE_SEND_F_GRD     40
#define  SCN_ROUTINE_SET_MODE_GRD   50
#define  SCN_ROUTINE_CHECK_MODE_2   60
#define  SCN_SUCCESS                80
#define  SCN_FAILED                 90

// ��������� �������� ���������� ������������
#define  SCL_OK                      0
#define  SCL_GET_CALIB_STATE        10
#define  SCL_CHECK_BUTTON           20
#define  SCL_SEND_CONTINUE          30
#define  SCL_SEND_BREAK             40


//
#define  CM_SEND_PAUSE_0        0
#define  CM_SEND_ENQ           10
#define  CM_WAITING_FOR_NAK    20
#define  CM_SEND_COMMAND       30
#define  CM_WAITING_FOR_ACK    40
#define  CM_WAITING_FOR_REPLY  50
#define  CM_SEND_ACK           60

#define  POS2_TIMEOUT        128
#define  DEFAULT_TIMEOUT     1000

#define  PB_ENQ              0x05
#define  PB_STX              0x02
#define  PB_ACK              0x06
#define  PB_NAK              0x15
#define  PB_BUSY             0x0B

#define POS2_BUF_LENGTH      (255 - 4)

#define ADC_BUF_SIZE         20

typedef struct
{
    uint8_t stx;
    uint8_t length;
    uint8_t buf[POS2_BUF_LENGTH];
} st_pos2;

typedef union
{
    st_pos2 fields;
    uint8_t packet[sizeof(st_pos2)];
} un_pos2;



namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
  Q_OBJECT

public:
  explicit MainWindow(QWidget *parent = 0);
  ~MainWindow();


  //QextSerialPort      * cp_port;
  //QList<QextPortInfo>   cp_ports_info;

  QSerialPort           * cp_port;

  void                  FillcbPort(void);

  QTimer              * tmr;
  QTimer              * tmr_timeout;

  QGraphicsScene       scene;


private slots:
  void timer_slot();
  void on_cb_comport_currentIndexChanged(int index);


  void on_pb_stop_clicked();

  void on_btn_continue_clicked();

  void on_btn_break_clicked();

private:
  Ui::MainWindow *ui;

  uint8_t        cmd_mode;

  void set_timeout(uint32_t milliseconds) { tmr_timeout->start(milliseconds); }
  bool is_timeout() { return !(tmr_timeout->isActive()); }
  void cp_port_send_byte(uint8_t byte);
  bool cp_port_set_baudrate(uint8_t baudrate);

  un_pos2  pos2_buf;
  uint8_t  pos2_r_buf[POS2_BUF_LENGTH];
  uint16_t pos2_r_buf_p;
  uint8_t  pos2_send_command_state;


  void pos2_clear();
  void pos2_add_byte(uint8_t byte);
  void pos2_add_crc();
  void pos2_send();
  bool pos2_send_command_prepare();   // ����������
  bool pos2_send_command_routine();   // true - ��������, false - � ��������

  bool pos2cmd_get_device_type();
  bool pos2cmd_get_chan_info();
  bool pos2cmd_get_chan_mode();
  bool pos2cmd_emu_key(uint8_t keycode);
  bool pos2cmd_set_chan_mode(uint8_t mode);
  bool pos2cmd_get_calib_info(void);
  bool pos2cmd_continue_calib(void);
  bool pos2cmd_break_calib(void);

  bool pos2_connect_prepare();
  bool pos2_connect_routine();

  bool pos2_fakegrd_prepare();
  bool pos2_fakegrd_routine();

  void pos2_receive_byte(uint8_t byte);
  bool pos2_is_received();

  void calibr_routine();

  //  bool   pos2_send_command_prepare(void);
  // uint8_t

  // ���������
  uint16_t   state_main;
  uint16_t   state_baudrate_cnt;
  uint16_t   state_connect;
  uint16_t   state_fakegrd;

  uint16_t   state_calibration;

  uint8_t    fakegrd_cnt;

  uint16_t   sl_1;

  QString    device_name;
  int8_t     device_chan_power;
  uint8_t    device_mode;

  uint8_t    is_connected;

  bool       btn_continue_pressed;
  bool       btn_break_pressed;

  // int32_t  adc_buf[ADC_BUF_SIZE];

  // void adc_put(int32_t adc);
  // void adc_paint(void);
  // cadcflt  adcflt;

};

#endif // MAINWINDOW_H
