/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Thu Apr 3 18:00:47 2014
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QLineEdit *le_prot_passw;
    QSpacerItem *horizontalSpacer;
    QComboBox *cb_comport;
    QPushButton *pb_stop;
    QVBoxLayout *verticalLayout;
    QLabel *lbl_baude;
    QLabel *lbl_state;
    QLabel *lbl_device;
    QLabel *lbl_scale_mode;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer_2;
    QTextEdit *te_info;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *le_password;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *btn_break;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *btn_continue;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(437, 255);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout_3 = new QVBoxLayout(centralWidget);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        le_prot_passw = new QLineEdit(centralWidget);
        le_prot_passw->setObjectName(QString::fromUtf8("le_prot_passw"));
        le_prot_passw->setMaximumSize(QSize(50, 16777215));

        horizontalLayout->addWidget(le_prot_passw);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        cb_comport = new QComboBox(centralWidget);
        cb_comport->setObjectName(QString::fromUtf8("cb_comport"));

        horizontalLayout->addWidget(cb_comport);

        pb_stop = new QPushButton(centralWidget);
        pb_stop->setObjectName(QString::fromUtf8("pb_stop"));

        horizontalLayout->addWidget(pb_stop);


        verticalLayout_3->addLayout(horizontalLayout);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lbl_baude = new QLabel(centralWidget);
        lbl_baude->setObjectName(QString::fromUtf8("lbl_baude"));

        verticalLayout->addWidget(lbl_baude);

        lbl_state = new QLabel(centralWidget);
        lbl_state->setObjectName(QString::fromUtf8("lbl_state"));

        verticalLayout->addWidget(lbl_state);

        lbl_device = new QLabel(centralWidget);
        lbl_device->setObjectName(QString::fromUtf8("lbl_device"));

        verticalLayout->addWidget(lbl_device);

        lbl_scale_mode = new QLabel(centralWidget);
        lbl_scale_mode->setObjectName(QString::fromUtf8("lbl_scale_mode"));

        verticalLayout->addWidget(lbl_scale_mode);


        verticalLayout_3->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalSpacer_2 = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);

        te_info = new QTextEdit(centralWidget);
        te_info->setObjectName(QString::fromUtf8("te_info"));
        QFont font;
        font.setPointSize(12);
        te_info->setFont(font);
        te_info->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        te_info->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        te_info->setUndoRedoEnabled(false);
        te_info->setReadOnly(true);

        verticalLayout_2->addWidget(te_info);

        verticalSpacer = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        verticalLayout_3->addLayout(verticalLayout_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        le_password = new QLineEdit(centralWidget);
        le_password->setObjectName(QString::fromUtf8("le_password"));
        le_password->setMaximumSize(QSize(70, 16777215));
        le_password->setEchoMode(QLineEdit::PasswordEchoOnEdit);

        horizontalLayout_2->addWidget(le_password);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        btn_break = new QPushButton(centralWidget);
        btn_break->setObjectName(QString::fromUtf8("btn_break"));
        btn_break->setEnabled(false);

        horizontalLayout_2->addWidget(btn_break);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        btn_continue = new QPushButton(centralWidget);
        btn_continue->setObjectName(QString::fromUtf8("btn_continue"));
        btn_continue->setEnabled(false);

        horizontalLayout_2->addWidget(btn_continue);


        verticalLayout_3->addLayout(horizontalLayout_2);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        le_prot_passw->setInputMask(QApplication::translate("MainWindow", "9999; ", 0, QApplication::UnicodeUTF8));
        le_prot_passw->setText(QApplication::translate("MainWindow", "0030", 0, QApplication::UnicodeUTF8));
        pb_stop->setText(QApplication::translate("MainWindow", "Connect", 0, QApplication::UnicodeUTF8));
        lbl_baude->setText(QApplication::translate("MainWindow", "Baude:", 0, QApplication::UnicodeUTF8));
        lbl_state->setText(QApplication::translate("MainWindow", "State:", 0, QApplication::UnicodeUTF8));
        lbl_device->setText(QApplication::translate("MainWindow", "Device", 0, QApplication::UnicodeUTF8));
        lbl_scale_mode->setText(QApplication::translate("MainWindow", "Scale mode:", 0, QApplication::UnicodeUTF8));
        te_info->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"></p></body></html>", 0, QApplication::UnicodeUTF8));
        le_password->setInputMask(QApplication::translate("MainWindow", "NNNNNN;_", 0, QApplication::UnicodeUTF8));
        btn_break->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\265\321\200\320\262\320\260\321\202\321\214", 0, QApplication::UnicodeUTF8));
        btn_continue->setText(QApplication::translate("MainWindow", "\320\237\321\200\320\276\320\264\320\276\320\273\320\266\320\270\321\202\321\214", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
